setwd("C:/Users/Asus/Desktop/IT24102351")
student_data <- read.csv("Exercise.csv")
summary(student_data$X1)

hist(student_data$X1,
     main = "Histogram of Age (X1)",
     xlab = "Age",
     col = "lightblue",
     border = "black")

#3
table(student_data$X2)

barplot(table(student_data$X2),
        main = "Gender Distribution (X2)",
        xlab = "Gender",
        ylab = "Frequency",
        col = c("pink","lightblue"))
#4
# Boxplot to see age variation by accommodation type
boxplot(X1 ~ X3, data = student_data,
        main = "Age by Accommodation Type",
        xlab = "Accommodation Type",
        ylab = "Age",
        col = c("lightgreen", "lightyellow", "lightcoral"))


