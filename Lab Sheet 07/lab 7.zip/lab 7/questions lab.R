#PS: Lab Sheet 07
#Exercise

setwd("C:\\Users\\Asus\\OneDrive\\Desktop\\lab 7")

#PART 1.1
punif(10,min=0,max=30,lower.tail = TRUE)

#PART 1.2
1-punif(20,min=0,max=30,lower.tail = TRUE)

#PART 2.1
pexp(3,rate=0.5,lower.tail = TRUE)

#PART 2.2
1-pexp(4,rate=0.5,lower.tail = TRUE)

#PART 2.3
pexp(4,rate=0.5,lower.tail = TRUE)-pexp(2,rate=0.5,lower.tail = TRUE)

#PART 3.1
1-pnorm(37.9,mean=36.8,sd=0.4,lower.tail = TRUE)

#PART 3.2
pnorm(36.9,mean=36.8,sd=0.4,lower.tail = TRUE)-pnorm(36.4,mean=36.8,sd=0.4,lower.tail = TRUE)

#PART 3.3
qnorm(0.012,mean=36.8,sd=0.4,lower.tail = TRUE)

#PART 3.4
qnorm(0.01,mean=36.8,sd=0.4,lower.tail = TRUE)

